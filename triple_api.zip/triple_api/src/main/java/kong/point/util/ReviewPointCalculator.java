package kong.point.util;

import kong.event.dto.EventReqDTO;
import kong.point.domain.ReviewPoint;
import kong.point.repository.PointRepository;
import kong.review.domain.Review;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Component
public class ReviewPointCalculator {

    private final PointRepository<ReviewPoint> pointRepository;

    // 리뷰 등록 시 몇 포인트를 얻는지 계산
    public int calculateAddActionPoint(EventReqDTO eventReqDTO, boolean isBonus) {

        int point = 0;
        if (eventReqDTO.hasContent()) {
            point++;
        }

        if (eventReqDTO.hasAttachedPhoto()) {
            point++;
        }

        if (isBonus) {
            point++;
        }

        return point;
    }

    public int calculateDeleteActionPoint(EventReqDTO eventReqDTO, boolean isBonus) {

        int point = 0;
        if (eventReqDTO.hasContent()) {
            point++;
        }

        if (eventReqDTO.hasAttachedPhoto()) {
            point++;
        }

        if (isBonus) {
            point++;
        }

        return -point;
    }

    // 리뷰 수정 시 몇 포인트를 얻는지 계산
    public int calculateModifyActionPoint(EventReqDTO eventReqDTO, boolean isBonus, Review review) {

        // Review Point NullPointerException 주의
        int point = 0;
        if (eventReqDTO.hasContent()) {
            point++;
        }

        if (eventReqDTO.hasAttachedPhoto()) {
            point++;
        }

        if (isBonus) {
            point++;
        }

        return point - sumPointValues(review);
    }

    private int sumPointValues(Review review) {
        return pointRepository.findReviewPointsByReview(review).stream()
                .mapToInt(ReviewPoint::getValue)
                .sum();
    }
}
