package kong.point.util;

public enum PointType {
    REVIEW;
}
