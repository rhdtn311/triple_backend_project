package kong.point.repository;

import kong.point.domain.Point;
import kong.point.domain.ReviewPoint;
import kong.review.domain.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PointRepository<T extends Point> extends JpaRepository<T, Long> {

    @Query("select r from ReviewPoint r where r.review = :review")
    public List<ReviewPoint> findReviewPointsByReview(@Param(value = "review") Review review);
}
