package kong.point.domain;

import kong.review.domain.Review;
import kong.user.domain.User;
import lombok.*;

import javax.persistence.*;

@NoArgsConstructor
@Getter
@Setter
@Entity
@DiscriminatorValue("REVIEW")
public class ReviewPoint extends Point {

    @ManyToOne
    private Review review;

    @Column(name = "is_bonus")
    private Boolean isBonus;

    @Builder
    public ReviewPoint(int value, User user, Review review, Boolean isBonus) {
        super(value, user);
        this.review = review;
        this.isBonus = isBonus;
    }
}
