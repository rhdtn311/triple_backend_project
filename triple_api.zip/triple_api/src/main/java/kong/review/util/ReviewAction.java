package kong.review.util;

import lombok.Getter;
import lombok.Setter;

public enum ReviewAction {

    ADD, MOD, DELETE;
}
