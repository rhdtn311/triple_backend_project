package kong.event.util;

public enum EventType {
    REVIEW;
}
