package kong.common.uuid;

import java.util.Arrays;

public class UuidManager {

    public static String toIndexingUuid(String uuid) {
        String[] uuidTokens = uuid.split("-");
        return uuidTokens[2] + uuidTokens[1] + uuidTokens[0] + uuidTokens[3] + uuidTokens[4];
    }

    public static String toUuid(String indexingUuid) {
        return indexingUuid.substring(8, 16) + "-" + indexingUuid.substring(4, 8) + "-" + indexingUuid.substring(0, 4) + "-" +
                indexingUuid.substring(16, 20) + "-" + indexingUuid.substring(20);
    }
}
